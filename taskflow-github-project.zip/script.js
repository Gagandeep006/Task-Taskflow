const input=document.getElementById('taskInput'), priority=document.getElementById('priorityInput'), list=document.getElementById('taskList'), empty=document.getElementById('empty');
let tasks=JSON.parse(localStorage.getItem('taskflow-tasks')||'[]'), filter='all';

function save(){localStorage.setItem('taskflow-tasks',JSON.stringify(tasks))}
function render(){
  list.innerHTML='';
  const visible=tasks.filter(t=>filter==='all'||(filter==='done'&&t.done)||(filter==='active'&&!t.done));
  empty.style.display=visible.length?'none':'block';
  visible.forEach(t=>{
    const li=document.createElement('li'); li.className='task'+(t.done?' done':'');
    li.innerHTML=`<button class="check" aria-label="Complete task"></button><span class="task-title"></span><span class="priority ${t.priority}">${t.priority}</span><button class="delete" aria-label="Delete task">×</button>`;
    li.querySelector('.task-title').textContent=t.title;
    li.querySelector('.check').onclick=()=>{t.done=!t.done;save();render()};
    li.querySelector('.delete').onclick=()=>{tasks=tasks.filter(x=>x.id!==t.id);save();render()};
    list.appendChild(li);
  });
  const done=tasks.filter(t=>t.done).length,total=tasks.length,active=total-done,pct=total?Math.round(done/total*100):0;
  document.getElementById('taskCount').textContent=`${total} ${total===1?'task':'tasks'}`;
  document.getElementById('totalStat').textContent=total;
  document.getElementById('doneStat').textContent=done;
  document.getElementById('activeStat').textContent=active;
  document.getElementById('progressText').textContent=pct+'%';
  document.getElementById('progressBar').style.width=pct+'%';
}
document.getElementById('taskForm').onsubmit=e=>{e.preventDefault();tasks.unshift({id:Date.now(),title:input.value.trim(),priority:priority.value,done:false});input.value='';save();render();input.focus()};
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');filter=b.dataset.filter;render()});
document.getElementById('themeBtn').onclick=()=>{document.body.classList.toggle('dark');document.getElementById('themeBtn').textContent=document.body.classList.contains('dark')?'☀':'☾'};
render();
