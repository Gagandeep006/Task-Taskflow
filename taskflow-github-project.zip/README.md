# TaskFlow — Smart Project Planner

A responsive productivity dashboard built with HTML, CSS and vanilla JavaScript.

## Features
- Add tasks with High / Medium / Low priority
- Mark tasks as completed
- Filter All / Active / Completed
- Progress percentage and task statistics
- Dark mode
- Local storage persistence
- Mobile responsive design

## Run locally
Open `index.html` in any modern browser.

## Deploy with GitHub Pages
1. Create a new GitHub repository named `taskflow`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. GitHub will provide your live Pages URL.

## Project
TaskFlow is a lightweight project-management concept designed to demonstrate a complete, deployable front-end experience.
